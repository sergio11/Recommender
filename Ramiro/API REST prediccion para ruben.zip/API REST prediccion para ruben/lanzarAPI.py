# -*- coding: utf-8 -*-
from flask import Flask, request
from werkzeug.utils import secure_filename
import os
import StringIO
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis
from sklearn.neighbors import KNeighborsClassifier
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.linear_model import LogisticRegression, SGDClassifier
from sklearn.ensemble import RandomForestClassifier as rf
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, AdaBoostClassifier
from sklearn.svm import SVC, LinearSVC, OneClassSVM
from sklearn.neural_network import MLPClassifier
from sklearn.naive_bayes import GaussianNB, BernoulliNB, MultinomialNB
from sklearn.externals import joblib
from sklearn.calibration import CalibratedClassifierCV
from utiles import make_sure_path_exists, listToCSV
import numpy as np
import csv
from sklearn.model_selection import cross_val_score
from sklearn import preprocessing
import datetime

app = Flask(__name__)

APP_ROOT = os.path.dirname(os.path.abspath(__file__))

rutaModelos = os.path.join(APP_ROOT, "modelos")

make_sure_path_exists(rutaModelos)

n_jobs = -1     # Seleccionando máximo número de cores
verbose = 10    # Seleccionando máximo nivel de mensajes


def devolverCsvAPI(nombreCSV):
    ### OBTENER PARAMETROS GET
    dataGET = request.args

    if dataGET and "nombreDumpModelo" in dataGET:
        nombreDumpModelo = dataGET["nombreDumpModelo"]
    else:
        return "Falta parametro de data dump modelo", 400

    rutaFichero = os.path.join(rutaModelos, nombreDumpModelo, nombreCSV)

    # Comprobando que hemos entrenado el modelo
    if not os.path.exists(os.path.join(rutaModelos, nombreDumpModelo)):
        return "No se ha entrenado modelo para la id: {0}".format(nombreDumpModelo), 400

    resultado = ""

    try:
        with open(rutaFichero, 'rb') as csvfile:
            spamreader = csv.reader(csvfile, delimiter=' ', quotechar='|')
            for row in spamreader:
                 resultado += ', '.join(row) + "\n"
    except IOError as e:
        print str(e)
        return "Error, no existe el fichero en: {0}".format(str(rutaFichero)), 400

    return resultado

# Funciona para controlar logging
def log(mensaje):
    print str(datetime.datetime.now().time()) + " - " + mensaje


# Entrena los datos eligiendo los mejores modelos despues de valorar varios. Salva todos los archivos necesarios en el sistema.
def entrenar(fichero, nombreDumpModelo, numModelo=None):
    # Protegiendo el sistema de posibles nombres de fichero que contengan paths dañinos. http://flask.pocoo.org/docs/0.12/patterns/fileuploads/
    nombreDumpModelo = secure_filename(nombreDumpModelo)

    # generar una carpeta en la que guardar todos los datos basada en la identidad que se le ha dado al modelo de forma que tenga una estructura funcional
    rutaIdModelo = os.path.join(rutaModelos, nombreDumpModelo)
    make_sure_path_exists(rutaIdModelo)

    ###Leer CSV obtenido
    df_leido = pd.read_csv(fichero)

    ### PREPROCESAR
    # Rellenando NaN a 0 en variables no categoricas
    categoricals = []
    for col, col_type in df_leido.dtypes.iteritems():
        if col_type == 'O':
            categoricals.append(col)
        else:
            df_leido[col].fillna(0, inplace=True)

    # Obtener nombre de la columna a predecir, que sera la ultima
    nombreColumnaClase = df_leido.columns[-1:]

    # Codificando con label encoder la columna de resultados
    
    le = preprocessing.LabelEncoder()
    le.fit(np.unique(df_leido[nombreColumnaClase].values.ravel()))

    x = df_leido

    # x = df_leido[df_leido.columns.difference(nombreColumnaClase)]
    # y = df_leido[nombreColumnaClase]

    x = pd.get_dummies(x, dummy_na=True)
    # y = le.transform(y.values.ravel())


    modelo =OneClassSVM(nu=0.1, kernel="rbf", gamma=0.1)

    # Entrenando modelo
    modelo.fit(x)

    ###SALVAR DATOS NECESARIOS

    # Salvar label encoder de la columna de resultado
    joblib.dump(le, os.path.join(rutaIdModelo, "labelEncoder.lb"))

    # salvando fichero csv de datos de entrenamiento, por si se quieren revisar o reutilizar
    df_leido.to_csv(os.path.join(rutaIdModelo, "datosEntrenamiento.csv"), index=False)

    #salvar preprocesado de datos para poder despues procesar en prediccion los datos que se nos aporten manteniendo el mismo formato de conversion ( en el caso de OHE es rellenar a ceros las columnas de los valores que no nos aporten en prediccion )
    joblib.dump(list(x.columns), os.path.join(rutaIdModelo, 'columnas_preprocesado.pkl'))

    #salvar preprocesado en formato csv para poder consultar sin utilizar la API REST
    listToCSV([list(x.columns)], os.path.join(rutaIdModelo, 'columnas_preprocesado.csv'))

    #salvar estructura de las columnas para recordarlo durante la prediccion
    listToCSV([df_leido.columns[:-1].tolist()], os.path.join(rutaIdModelo, "columnas.csv"))

    # salvar modelo
    joblib.dump(modelo, os.path.join(rutaIdModelo, "modelo.pkl"))

    return "Entrenamiento realizado con exito"

    # with pd.option_context('display.max_rows', None, 'display.max_columns', None):
    #     print(df_preprocesado)


# Predice la probabilidad de las salidas ( en el caso de estados la probabilidad de fallo y de exito ).
def predecir(fichero, nombreDumpModelo):

    # genera ruta donde se ha guardado el modelo que se ha elegido
    rutaIdModelo = os.path.join(rutaModelos, nombreDumpModelo)

    # Comprobando que hemos entrenado el modelo
    if not os.path.exists(rutaIdModelo):
        return "No se ha entrenado modelo para la id: {0}".format(nombreDumpModelo), 400

    ###Leer CSV obtenido
    df_leido = pd.read_csv(fichero)


    ###PREPROCESAR
    # Rellenando NaN a 0 en variables no categoricas
    categoricals = []
    for col, col_type in df_leido.dtypes.iteritems():
        if col_type == 'O':
            categoricals.append(col)
        else:
            df_leido[col].fillna(0, inplace=True)


    # Tranformando variables categoricas a numericas de forma que no haya problemas de ordinalidad
    df_preprocesado = pd.get_dummies(df_leido, dummy_na=True)

    #cargar preprocesado hecho en entrenamiento y utilizar el mismo para generar columnas vacias para aquellos valores que no nos hayan aportado en prediccion
    rutaFicheroColumnasPrep = os.path.join(rutaIdModelo, 'columnas_preprocesado.pkl')
    try:
        columnas_preprocesado = joblib.load(rutaFicheroColumnasPrep)
    except IOError as e:
        print str(e)
        return "Error, no existe el fichero en: {0}".format(str(rutaFicheroColumnasPrep)), 400

    for col in columnas_preprocesado:
        if col not in df_preprocesado.columns:
            df_preprocesado[col] = 0

    # Ordenar las columnas de la misma forma que en el entrenamiento
    df_preprocesado=df_preprocesado[columnas_preprocesado]

    ### CARGAR MODELO
    rutaFicheroModelo = os.path.join(rutaIdModelo, "modelo.pkl")
    try:
        modelo = joblib.load(rutaFicheroModelo)
    except IOError as e:
        print str(e)
        return "Error, no existe el fichero en: {0}".format(str(rutaFicheroModelo)), 400

    # cargar label encoder para codificar la columna de resultado
    try:
        le = joblib.load(os.path.join(rutaIdModelo, "labelEncoder.lb"))
    except IOError as e:
        print str(e)
        return "Error, no existe el fichero en: {0}".format(str(rutaFicheroModelo)), 400

    ###PREDICCION
    # obtener una prediccion
    prediccion = modelo.predict(df_preprocesado)

    # obtener y devolver la probabilidad de fallo
    return pd.DataFrame(modelo.predict(df_preprocesado)).to_csv(index=False)


# Entrada de API REST para entrenamiento.
""" USO

Tipo de petición: POST

Llamar a: direccion:puerto/entrenamiento?nombreDumpModelo=nombre

ENTRADA:
    Parámetros GET:  Enviar por parámetro GET nombreDumpModelo, el cual es la identidad del modelo que se salvará en el sistema. Si se utiliza el mismo nombre que un modelo anterior se sobreescribe.

    Parámetros POST: File: Archivo en formato CSV estructurado como los que se encuentran en la carpeta datos. Estos serán los datos de entrenamiento.
                            En este fichero CSV, la última columna debe ser el target a predecir, en el caso de estados es el fallo o éxito.
                            La primera fila deben ser los nombres de las columnas, los cuales son muy importantes porque deben reutilizarse en la predicción.

SALIDA:
    Se almacena en la carpeta modelos, en una carpeta llamada como el nombreDumpModelo aportado, el modelo generado para poder predecir con el así como todos los datos necesarios.

    La petición POST devuelve un mensaje de éxito o de error.

"""
@app.route('/entrenamiento', methods=['POST', 'PUT'])
def apiEntrenamiento():
    ### OBTENER PARAMETROS GET
    dataGET = request.args

    
    numModelo = None
    if dataGET:
        if "nombreDumpModelo" in dataGET:
            nombreDumpModelo = dataGET["nombreDumpModelo"]
        else:
            return "Falta parametro nombreDumpModelo", 400
        if "numModelo" in dataGET:
            numModelo = int(dataGET["numModelo"])
            if numModelo<0 or numModelo>=len(MODELOS):
                return "numModelo no contiene un valor adecuado", 400
        else:
            numModelo = None
    else:
        return "Falta parametro nombreDumpModelo", 400

    ###OBTENER FICHERO DE DATOS PARA ENTRENAMIENTO

    # Comprobacion de envio de fichero
    if not 'file' in request.files:
        return "No se ha enviado un archivo como 'file'", 400

    # obtener fichero
    file = request.files['file']

    ###PROCESAR CONTENIDO DEL FICHERO
    # contenido a string
    file_contents_string = file.stream.read().decode("utf-8")

    # string a fichero simulado
    file_string_IO = StringIO.StringIO(file_contents_string)

    ### ENTRENAR Y OBTENER RESULTADOS
    # entrenamiento
    return entrenar(file_string_IO, nombreDumpModelo, numModelo)



# Entrada de API REST para predicción.
""" USO

Tipo de petición: POST

Llamar a: direccion:puerto/prediccion?nombreDumpModelo=nombre

ENTRADA:
    Parámetros GET:  Enviar por parámetro GET nombreDumpModelo, el cual es la identidad del modelo que debe haber sido entrenado previamente.

    Parámetros POST: File: Archivo en formato CSV estructurado como los que se encuentran en la carpeta datos. Estos serán los datos que se utilizarán de los estados para predecir la probabilidad de fallo.
                            En este CSV no debe estar la columna target, ya que es desconocida y es de la que queremos averiguar la probabilidad.
                            Debe contener el resto de columnas utilizadas en entrenamiento. Importante que la primera fila es el nombre de las columnas y este nombre de columnas debe contener todas aquellas utilizadas en entrenamiento manteniendo los nombres.
                            En caso de no mantenerlos el código los rellena a ceros y no da error actualmente, pero es un error.
SALIDA:
    La petición POST devuelve un mensaje de error o texto en formato CSV donde la primera fila son los valores de la columna a predecir y cada una de las siguientes filas es la probabilidad de error para esos valores de la primera.

"""
@app.route('/prediccion', methods=['POST', 'PUT'])
def apiPrediccion():
    ### OBTENER PARAMETROS GET
    dataGET = request.args

    if dataGET and "nombreDumpModelo" in dataGET:
        nombreDumpModelo = dataGET["nombreDumpModelo"]
    else:
        return "Falta parametro de data dump modelo", 400

    ###OBTENER FICHERO DE DATOS PARA PREDICCION
    if not 'file' in request.files:
        return "No se ha enviado un archivo como 'file'", 400

    #obtencion de fichero
    file = request.files['file']

    # contenido a string
    file_contents_string = file.stream.read().decode("utf-8")

    # string a fichero simulado
    file_string_IO = StringIO.StringIO(file_contents_string)

    ### PREDECIR Y OBTENER RESULTADOS
    # prediccion
    prediccion = predecir(file_string_IO, nombreDumpModelo)

    ###DEVOLVER LOS RESULTADOS
    return prediccion


# Entrada de API REST para recuperar la lista de columnas utilizadas durante el entrenamiento de un modelo
""" USO

Tipo de petición: GET

Llamar a: direccion:puerto/columnas?nombreDumpModelo=nombre

ENTRADAS:
    Parámetros GET:  Enviar por parámetro GET nombreDumpModelo, el cual es la identidad del modelo que debe haber sido entrenado previamente.

SALIDAS:
    Se devuelve error o la lista de nombres de columnas pasadas en entrenamiento separadas por comas y en el mismo orden.
"""
@app.route('/columnas', methods=['GET'])
def apiColumnas():
    return devolverCsvAPI("columnas.csv")

# Entrada de API REST para recuperar la lista de columnas utilizadas durante el entrenamiento, preprocesadas, de un modelo
""" USO

Tipo de petición: GET

Llamar a: direccion:puerto/columnasPreprocesado?nombreDumpModelo=nombre

ENTRADAS:
    Parámetros GET:  Enviar por parámetro GET nombreDumpModelo, el cual es la identidad del modelo que debe haber sido entrenado previamente.

SALIDAS:
    Se devuelve error o la lista de nombres de columnas pasadas en entrenamiento preprocesadas, separadas por comas y en el mismo orden.
"""
@app.route('/columnasPreprocesado', methods=['GET'])
def apiColumnasPreprocesadas():
    return devolverCsvAPI("columnas_preprocesado.csv")

# Entrada de API REST para recuperar el orden de los algoritmos, lo cual es util para poder indicar un algoritmo individual a la hora de realizar el entrenamiento
""" USO

Tipo de petición: GET

Llamar a: direccion:puerto/ordenAlgoritmos

ENTRADAS:

SALIDAS:
    Se devuelve una lista en formato CSV, donde la primera columna es el id u orden de cada algoritmo y la segunda sus nombres.
"""
@app.route('/ordenAlgoritmos', methods=['GET'])
def ordenAlgoritmos():
    retorno = ""
    for i in range(len(MODELOS)):
        retorno += "{0},{1}\n".format(i,str(MODELOS[i].__class__.__name__))
    return retorno

# Entrada de API REST para recuperar la puntuación de cada algoritmo probado durante el entrenamiento
""" USO

Tipo de petición: GET

Llamar a: direccion:puerto/puntuaciones?nombreDumpModelo=nombre

ENTRADAS:
    Parámetros GET:  Enviar por parámetro GET nombreDumpModelo, el cual es la identidad del modelo que debe haber sido entrenado previamente.

SALIDAS:
    Se devuelve error o una lista en formato CSV en la que la primera columna es la precisión del algoritmo, entre 0 y 1, siendo 1 100% de acierto.
    La segunda columna son los nombres de los algoritmos. Están ordenados por puntuación, siendo el primer algoritmo el que tiene mayor puntuación y por tanto el utilizado para generar el modelo.
"""
@app.route('/puntuaciones', methods=['GET'])
def apiPuntuaciones():
    return devolverCsvAPI("modelScores.csv")

# Entrada de API REST para recuperar los datos utilizados para entrenar un modelo
""" USO

Tipo de petición: GET

Llamar a: direccion:puerto/datos?nombreDumpModelo=nombre

ENTRADAS:
    Parámetros GET:  Enviar por parámetro GET nombreDumpModelo, el cual es la identidad del modelo que debe haber sido entrenado previamente.

SALIDAS:
    Se devuelve error o los datos utilizados para entrenar el modelo en formato CSV
"""
@app.route('/datos', methods=['GET'])
def apiDatos():
    return devolverCsvAPI("datosEntrenamiento.csv")
    

#####################
# CODIGO DE PRUEBAS #
#####################
"""
El siguiente código solo tiene como objetivo hacer pruebas rápidas de funcionamiento de la API REST
"""

@app.route('/')
def index():
    return "Este es el index"

# direccion: localhost:puerto/parametros/PARAMETRO
@app.route('/holaMundo', methods=['GET'])
def holaMundo():
    return "Hola Mundo"

# Para pasar un parametro a esta direccion cambiar PARAMETRO: localhost:puerto/parametros/PARAMETRO
@app.route('/parametros/<string:aqui>', methods=['GET'])
def ejemploParametro(aqui):

    return "Parametro: " + str(aqui)

# Envio de parametros por POST
@app.route('/envioDatos', methods=['GET', 'POST'])
def envioPOST():
    if request.method == 'GET':
        data = request.args
        cadena = "Se ha recibido GET<br>"


    if request.method == 'POST':
        data = request.form  # a multidict containing POST data
        dataJson = request.get_json()
        cadena = "Se ha recibido POST<br>"
        cadena += str(dataJson) + "<br>"

    return cadena + "Datos recibidos: " + str(data)

# Obtencion de JSON
# Envio de parametros por POST
@app.route('/envioJSON', methods=['POST'])
def datosJSON():
    dataJson = request.get_json()

    return "Datos de JSON recibidos: " + str(dataJson)

# Retorno de error
@app.route('/error400')
def error400():
    return "Devuelvo error 400", 400



if __name__ == '__main__':
    app.run(debug=True)


